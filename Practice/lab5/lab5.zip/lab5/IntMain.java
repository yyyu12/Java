/**
* @author author_name
* @since 3.0
* @version 3.0
 */
public class IntMain {
    /**
    * The starting point of the Java application.
    * @param args command line arguments
     */
    public static void main(String[] args) {
        int[] linearData = {0, 9, 7, 3, 5, 6};
        System.out.println(new IntegerMatrix(2,3, linearData));
    }
}