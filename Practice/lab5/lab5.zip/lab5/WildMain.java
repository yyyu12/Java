public class WildMain {
    public static void main(String[] args) {
        System.out.println(WildAnimal.ELEPHANT.toString());
        System.out.println(WildAnimal.listAllAnimals());
    }
}